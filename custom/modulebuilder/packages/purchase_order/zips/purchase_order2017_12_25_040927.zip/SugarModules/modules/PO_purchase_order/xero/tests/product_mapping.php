<?php 
$product_mapping = array(
"adfa2b8d-1f93-a3f3-c9ae-599162f3111f" =>	"Switchboard Upgrade",
	
"f1d13f20-8ac4-7998-f60e-595360b739a8" =>	"Daikin Nexura 4.8kW",
"687c3167-094a-bb17-40d9-59535f5cf7f4" =>	"DaikinNexura35",
"ddd3e2ba-6fac-9b75-cda5-59535d50cac6" =>	"Daikin Nexura 2.5kW",
"b31e9ae7-d2d2-5462-80da-59488b9c24f1" =>	"Daikin Cora 3.5",
	
"6e9623d8-be48-0ef0-51af-5922462d9f6b" =>	"DaikinCora2",
	
	
"a7be5deb-9a6d-d459-7856-58fd98483620" =>	"250EQTAQ", //"Sand250PLUS",
"8a9c327b-0a91-b30a-7d46-58fd988cd4af" =>	"Sanden 315L Short Plus",
"9ba3d71b-580b-f094-da83-58fd98ccc9c7" =>	"Sanden 315 Tall Plus",
"ccb7cb54-65ba-5210-7e04-58dc66c1139d" =>	"CONSULTING",
	
"7048e3d3-12e7-7f3e-2053-58afce060c27" =>	"DaikinCora5",
	
	
"64e60160-dd77-a138-70f2-584115dc7a71" =>	"SandenDelivery",
// Update 1/SEP
"9d6d2839-a581-34bc-595c-57ca798868f2" => "Methven Rail Shower",

    "1c262ce4-8022-f52e-aba0-57ca45984248" => "Methven Hand Held+Hose",
"97b9460b-1dd3-f312-354d-57c990f179d9"=>"Methven Rose on Modern Arm",
"43acb4fe-b140-9922-fdbe-579ec4150363"=>"Methven Rose only",
	"da0636b8-1ad6-d182-16d5-56c126f53fe5"=>"Methven_Shipping_Handling",
"9d830d1d-d9f4-556f-b94c-56c124e2dc0e"=>"Methven Dual Pivot Arm",
"7bb7edb8-0242-62dc-696a-56c1240d4f11"=>"Methven Hand Held",
//""=>"",
    "78b8b420-5003-8249-3dd3-5918dd4d0d06" => "SolarSales",
"8a5e7211-8930-02f9-9852-582a71209b49" =>	"CONSULTING",
	
	
	
"629d17cc-5526-7b68-2efb-580db384ee47" =>	"CONSULTING",
"b08cf5c3-cfde-9934-9457-580daa22ca0e" =>	"Discount",
"742aed09-2694-fdad-d879-580da9bbf3a3" =>	"SandenElecInstall",
"3f3a3226-8f23-6c5b-b722-5809810bda90" =>	"DaikinComplexInstall",
"14c893c8-ca0a-acdb-f176-58098000ae6b" =>	"DaikinInstall",
"d8fec4f3-0783-6033-05f1-5808864f7fcb" =>	"SANPICOMP",
"4e18c2c7-6847-2f37-a1dc-580034731a93" =>	"SANDENPLUMBINSTAL",
"dcdfb0f2-c0d5-cdb2-7368-57f73bb8f3d6" =>	"DaikinDelivery",
	
	
"6de74b15-94c6-bda8-611f-57cf89b395ba" =>	"CONSULTING",
"6327b12b-81bf-6abb-735e-57ceb72d172c" =>	"CONSULTING",
"e83b5f2d-ed02-ee9c-d5a8-57ce8689a360" =>	"CONSULTING",
"2a83b044-8bfb-5990-1fe2-57ce811f84b2" =>	"CONSULTING",
"9c60055a-49c0-6f43-635d-57ce3f016719" =>	"Discount",
"9d6d2839-a581-34bc-595c-57ca798868f2" =>	"Methven Rail Shower",
"1c262ce4-8022-f52e-aba0-57ca45984248" =>	"Methven Hand Held+Hose",
"97b9460b-1dd3-f312-354d-57c990f179d9" =>	"Methven Rose on Modern Arm",
	
"5e1fbede-0be8-0595-2f86-57b573f6c566" =>	"DaikinDelivery",
"28259986-0833-e30b-9cb3-57b3e26cd2fb" =>	"DWifi",
"ef81036f-9889-234d-02e5-57b2c0c71e79" =>	"DaikinUS75",
"b81662be-8244-1c71-d91d-57aae32fc5bd" =>	"CONSULTING",
"c2ee9a10-62ef-86e9-73d5-57aae28cd00d" =>	"CONSULTING",
"91f957c4-ae31-19a9-119a-57aae26fd4a9" =>	"CONSULTING",
"4af5296e-78c2-0b77-a5e5-57aae2a4256f" =>	"CONSULTING",
"43acb4fe-b140-9922-fdbe-579ec4150363" =>	"Methven Rose only",
"9a8e2c4a-e826-a794-8247-5798ae854aa5" =>	"SANDPLUMBSLAB",
"1b0a451b-5410-8a5c-286a-5798ae3d2ec0" =>	"SANDPLUMBSLAB",
"4d9b1ad8-794e-5fd5-d948-574fd085b1a8" =>	"SANPICOMP",
"cbfafe6b-5e84-d976-8e32-574fc106b13f" =>	"Rebate",
	
	
"8822e040-6ff7-9917-627f-56e8b3111cc2" =>	"DaikinCora2.5",
	
"9d830d1d-d9f4-556f-b94c-56c124e2dc0e" =>	"Methven Dual Pivot Arm",
"7bb7edb8-0242-62dc-696a-56c1240d4f11" =>	"Methven Hand Held",
"237708be-63a5-18fa-9f44-56c10f5a218f" =>	"Sand250PLUS",
"45f9e920-649b-fe0d-18a3-56b9a9d688ee" =>	"Methven Rail Shower",
	
"4b5032ca-8aab-60eb-2837-56b82333ea38" =>	"DWifi",
	
"571aa1b6-9abe-80ec-5cdd-56b4536a29d0" =>	"DaikinUS735",
"b0df5c09-26fa-a091-5536-56977c44cdfd" =>	"SandenElecInstall",
"562c34e0-5231-cd0e-2af6-56977821b1e4" =>	"SANDENPLUMBINSTALL",
"4efbea92-c52f-d147-3308-569776823b19" =>	"Rebate",
"a86e4e9a-90a7-b988-d944-56977107e657" =>	"Sanden 315 Tall Plus",
	
"cd46e7e8-cf7b-9fd7-e7a3-56963d42ddb5" =>	"Sanden 315L Short Plus",
"550e79bb-3be6-9478-e801-5696179803c1" =>	"DaikinDelivery",
"58d946f3-36c2-1b70-d9e2-56951ddcb660" =>	"DaikinInstall",
"e3124bc6-0cd9-88ec-9da6-56951c2dafbb" =>	"Daikin _Install_Extra",
"c4f1979b-d540-53ca-d95b-56951023eaf9" =>	"DaikinDelivery",
"3518d3a1-7c11-77c5-b9db-5694fed992e6" =>	"DaikinUS725",
    "eab4f939-4f8e-9598-c6c3-59b63f046afd" =>"Sanden single unit",
    "cc26d412-9a7d-a734-8fbb-59c9a80110b2"=>"Warranty_Saden",
    "2e3e02ab-596c-aa4d-ec75-59dae3a11c63" => "S315EQTAQ",

);